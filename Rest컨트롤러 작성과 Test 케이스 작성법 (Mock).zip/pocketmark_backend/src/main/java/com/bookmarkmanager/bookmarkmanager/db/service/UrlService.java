package com.bookmarkmanager.bookmarkmanager.db.service;

public class UrlService {
}
