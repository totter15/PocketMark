package com.bookmarkmanager.bookmarkmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookmarkmanagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookmarkmanagerApplication.class, args);
    }

}
